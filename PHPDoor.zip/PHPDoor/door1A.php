<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<p>The melody grows louder as you step inside. The room is lined with glass tubes, each containing what appears to be dormant Disassembly Drones. In the center of the room is a console with a glowing blue screen. The hum seems to emanate from it.</p>";
    echo "<p>Suddenly, the screen displays a message:</p>";
    echo "<p><b>“Override Code Required. Drones will activate in 30 seconds.”</b></p>";

    $doors = [
        [
            "title" => "Option 1",
            "description" => "<b>Search for the override code:</b> You frantically search the room, finding a datapad with partial codes."
        ],
        [
            "title" => "Option 2",
            "description" => "<b>Destroy the console:</b> You grab a nearby metal object and smash the console, hoping it will stop the countdown."
        ],
    ];
    
    $options = [
        ["href" => "door1Awin.php", "title" => "Option 1", "image" => "assets/Green.png"],
        ["href" => "door1Alose.php", "title" => "Option 2", "image" => "assets/Blue.png"],
    ];
    ?>

<div class="container">
    <?php foreach ($doors as $door): ?>
        <div class="block">
            <h1><?php echo $door['title']; ?></h1>
            <p><?php echo $door['description']; ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="doors">
    <?php foreach ($options as $option): ?>
        <a href="<?= $option['href']; ?>">
            <h1><?= $option['title']; ?></h1>
            <div class="door" style="background-image: url('<?= $option['image']; ?>');"></div>
        </a>
    <?php endforeach; ?>
</div>
</body>
</html>