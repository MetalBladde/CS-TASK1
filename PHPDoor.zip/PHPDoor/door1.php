<!DOCTYPE html>
<html>
<head>
    <title>Door 1 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>Escape from Copper 9</h1>";
    echo "<p>You awaken, disoriented, on the cold metallic floor of an abandoned human facility on Copper 9. The sound of distant machinery echoes through the halls, and the faint smell of oil fills your sensors. A dim, flickering light barely illuminates the corridor ahead, where three doors stand ominously.</p>";
    echo "<p>Each door is marked with strange, glitching symbols that seem to distort when you focus on them. Above the doors, an ancient sign reads:</p>";
    echo "<p>Project Disassembly: Lab 42. Proceed with Caution.</p>";
    echo "<p>A speaker crackles to life, startling you.</p>";

    $quote = <<<EOT
"<i>Oh, fantastic. Another unlucky idiot stuck in this death maze. Pro tip: don’t die. Not that I care or anything, but, you know, I’d feel a little bad. Or not. Whatever. Pick a door, genius.</i>"
<br>The voice is unmistakably Uzi’s, her sarcasm dripping with just a hint of concern.
EOT;

echo "<blockquote><p>$quote</p></blockquote>";


$doors = [
    [
        "title" => "Door 1",
        "description" => "A haunting melody hums softly from the other side. It’s soothing... but something about it feels off."
    ],
    [
        "title" => "Door 2",
        "description" => "The grinding sound of claws against steel grows louder the closer you get. A faint, red light seeps from beneath the door."
    ],
    [
        "title" => "Door 3",
        "description" => "No sound comes from beyond this door, but a faint chemical smell, sharp and acrid, wafts through the cracks."
    ]
];

$options = [
    ["href" => "door1A.php", "title" => "Door 1", "image" => "assets/Green.png"],
    ["href" => "door1B.php", "title" => "Door 2", "image" => "assets/Blue.png"],
    ["href" => "door1C.php", "title" => "Door 3", "image" => "assets/Red.png"],
];
?>

<div class="container">
    <?php foreach ($doors as $door): ?>
        <div class="block">
            <h1><?php echo $door['title']; ?></h1>
            <p><?php echo $door['description']; ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="doors">
    <?php foreach ($options as $option): ?>
        <a href="<?= $option['href']; ?>">
            <h1><?= $option['title']; ?></h1>
            <div class="door" style="background-image: url('<?= $option['image']; ?>');"></div>
        </a>
    <?php endforeach; ?>
</div>


</body>
</html>
