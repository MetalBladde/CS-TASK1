<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<p>You step through the door into a laboratory filled with vials of glowing green liquid. A hologram of a human scientist flickers to life.</p>";
    echo "<p><i>“Ah, a survivor. You’ll need this,”<i> the hologram says, indicating a syringe filled with the green liquid. <i>“It’s your only chance against the drones. But be warned, it has... side effects.”</i></i></p>"
    ?>

    <?php
    $doors = [
        [
            "title" => "Option 1",
            "description" => "<p><b>Inject the liquid:</b> You feel a surge of power coursing through your circuits. Your senses sharpen, and you’re faster than ever, but your vision glitches, and you start hearing voices.</p>"
        ],
        [
            "title" => "Option 2",
            "description" => "<p><b>Refuse the injection:<b> You search the lab for another solution, finding a map of the facility and a keycard.</p>"
        ],
    ];
    
    $options = [
        ["href" => "door1Close.php", "title" => "Option 1", "image" => "assets/Green.png"],
        ["href" => "door1Cwin.php", "title" => "Option 2", "image" => "assets/Blue.png"],
    ];
    ?>

<div class="container">
    <?php foreach ($doors as $door): ?>
        <div class="block">
            <h1><?php echo $door['title']; ?></h1>
            <p><?php echo $door['description']; ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="doors">
    <?php foreach ($options as $option): ?>
        <a href="<?= $option['href']; ?>">
            <h1><?= $option['title']; ?></h1>
            <div class="door" style="background-image: url('<?= $option['image']; ?>');"></div>
        </a>
    <?php endforeach; ?>
</div>
</body>
</html>
