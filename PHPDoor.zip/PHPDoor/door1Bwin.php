<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>YOU SURVIVED!</h1>";
    echo "<p>You manage to injure V just enough to escape, but you’re badly damaged. You escaped the place</p>";
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>
