<!DOCTYPE html>
<html>
<head>
    <title>Magic Door Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h1>Magic Door Adventure</h1>
    <p>Welcome to the Magic Door Adventure! Each door leads to a different story. Choose wisely!</p>
    <div class="doors">
    <a href="door1.php">
        <h1>Door 1</h1>
        <div class="door" style="background-image: url('assets/Green.png');"></div>
    </a>
    <a href="door2.php">
        <h1>Door 2</h1>
        <div class="door" style="background-image: url('assets/Blue.png');"></div>
    </a>
    <a href="door3.php">
        <h1>Door 3</h1>
        <div class="door" style="background-image: url('assets/Red.png');"></div>
    </a>
</div>

</body>
</html>
