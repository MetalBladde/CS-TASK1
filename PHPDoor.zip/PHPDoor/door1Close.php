<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>YOU LOSE</h1>";
    echo "<p>The side effects overwhelm you, and you lose control, turning into a monster yourself.</p>";
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>
