<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>The Forgotten Violin</h1>";
    echo "<p>In a quiet town, Elliot discovered his late grandfathers violin in the attic. Though Elijah had once been a celebrated violinist, the instrument had sat silent for years.</p>";
    echo "<p>Curious, Elliot began practicing, struggling at first but slowly coaxing melodies from the strings. One evening, an elderly neighbor heard him playing by the window. <i>“Your grandfather would be proud,”</i> she said, revealing she had known Elijah.</p>";
    echo "<p>Inspired, Elliot poured himself into the music, performing for small crowds until his passion blossomed into a career. With every note, he felt connected to his grandfather, carrying his legacy forward.</p>";
    echo "<h1>The End</h1>"
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>
