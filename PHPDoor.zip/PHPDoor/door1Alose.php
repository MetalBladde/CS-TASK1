<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>YOU DIED </h1>";
    echo "<p>The console’s destruction triggers an alarm, and the drones awaken in a frenzy. They charge at you, destroying you in the process.</p>";
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>
