<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>YOU WIN!</h1>";
    echo "<p>The map leads you to a hidden passage, bypassing the worst dangers, AND GRANTING YOU ESCAPE</p>";
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>
