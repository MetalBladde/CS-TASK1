<!DOCTYPE html>
<html>
<head>
    <title>Door 3 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>The Paper Bird</h1>";
    echo "<p>Maya loved folding paper cranes. Each one, she believed, carried a wish. Her small room was filled with colorful birds strung from the ceiling, swaying gently like dreams caught in flight.</p>";
    echo "<p>One day, while walking through the park, Maya noticed an elderly man feeding pigeons. He looked lonely, his eyes heavy with stories no one had heard. Maya smiled, handed him a bright red paper crane, and whispered, <i>“It’s for a wish.”</i></p>";
    echo "<p>The man stared at the bird, then at her. Slowly, his lips curved into a smile. <i>“Thank you,”</i> he said softly.</p>";
    echo "<p>Days turned into weeks, and Maya found herself visiting the park often, folding more cranes to give away. Each bird, she realized, wasn’t just for wishes—they were small tokens of connection, lifting spirits one fold at a time.</p>";
    echo "<h1>The End</h1>"
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>
