<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<h1>YOU SURVIVED!</h1>";
    echo "<p>Success: You enter the correct code just in time, deactivating the drones and escaping!</p>";
    ?>
    <a href="index.php">Back to Doors</a>
</body>
</html>