<!DOCTYPE html>
<html>
<head>
    <title>Door 2 Adventure</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php
    echo "<p>You step through the door into a dimly lit hallway. The grinding sound crescendos as the shadow of a Murder Drone emerges from the darkness. It’s V, her glowing yellow eyes locking onto you.</p>";
    echo "<p><i>A new plaything? How delightful,</i> she says with a twisted grin.</p>";


$doors = [
    [
        "title" => "Option 1",
        "description" => "<p><b>Run down the hallway:</b> You sprint as fast as you can, dodging Cyn’s claws as she tears through the walls in pursuit. Ahead, you see a door marked “EXIT.” Will you make it?</p>"
    ],
    [
        "title" => "Option 2",
        "description" => "<p><b>Stand your ground:</b> You grab a broken pipe nearby and prepare to fight.</p>"
    ],
];

$options = [
    ["href" => "door1Blose.php", "title" => "Option 1", "image" => "assets/Green.png"],
    ["href" => "door1Bwin.php", "title" => "Option 2", "image" => "assets/Blue.png"],
];
?>

<div class="container">
    <?php foreach ($doors as $door): ?>
        <div class="block">
            <h1><?php echo $door['title']; ?></h1>
            <p><?php echo $door['description']; ?></p>
        </div>
    <?php endforeach; ?>
</div>

<div class="doors">
    <?php foreach ($options as $option): ?>
        <a href="<?= $option['href']; ?>">
            <h1><?= $option['title']; ?></h1>
            <div class="door" style="background-image: url('<?= $option['image']; ?>');"></div>
        </a>
    <?php endforeach; ?>
</div>
</body>
</html>
